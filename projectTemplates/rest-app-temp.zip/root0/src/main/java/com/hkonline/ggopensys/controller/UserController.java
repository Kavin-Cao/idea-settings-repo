package ${IJ_BASE_PACKAGE}.ggopensys.controller;

import ${IJ_BASE_PACKAGE}.common.dto.ApiResponse;
import ${IJ_BASE_PACKAGE}.ggopensys.service.UserService;
import ${IJ_BASE_PACKAGE}.ggopensys.vo.SimpleAuthVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController extends BaseController {

    @Autowired
    private UserService userService;

    @PostMapping("/simpleAuth")
    public ApiResponse simpleAuth(SimpleAuthVo vo) {
        return userService.simpleAuth(vo);
    }
}
