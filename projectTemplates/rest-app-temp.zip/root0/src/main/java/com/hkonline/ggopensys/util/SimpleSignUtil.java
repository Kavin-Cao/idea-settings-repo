package ${IJ_BASE_PACKAGE}.ggopensys.util;

import com.google.common.collect.Lists;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * 简单签名工具类
 * 签名生成的通用步骤如下：
 * 第一步，设所有发送或者接收到的数据为集合M，将集合M内非空参数值的参数按照参数名ASCII码从小到大排序（字典序），
 * 使用URL键值对的格式（即key1=value1&key2=value2…）拼接成字符串stringA。
 * 特别注意以下重要规则:
 * - 参数名ASCII码从小到大排序（字典序）;
 * - 如果参数的值`为空不参与签名`;
 * - 参数名区分大小写;
 * - 验证调用返回或港港主动通知签名时，传送的sign参数不参与签名，将生成的签名与该sign值作校验。
 * - 港港跨境接口可能增加字段，验证签名时必须支持增加的扩展字段
 * 第二步，在stringA【前、后】都拼接上apiKey得到stringSignTemp字符串，并对stringSignTemp进行MD5运算，
 * 再将得到的字符串所有字符转换为大写，得到sign值signValue。生产环境apiKey由港港跨境方提供,
 */
public class SimpleSignUtil {
    private SimpleSignUtil(){}

    /**
     * 生成签名
     * @param params
     * @param apiKey
     * @param type 加密类型,支持两种类型:MD5, SHA256
     * @return
     */
    public static String sign(Map<String, Object> params,String apiKey, String type){
        TreeMap<String, Object> sortedParams = new TreeMap<>();
        params.forEach((k,v)->{
            if(StringUtils.isNotBlank(k)){
                if(v instanceof String){
                    if(StringUtils.isNotBlank((String) v)){
                        sortedParams.put(k, v);
                    }
                }else if(v != null){
                    sortedParams.put(k, v);
                }
            }
        });
        List<String> kvList = Lists.newArrayList();
        sortedParams.forEach((k,v) -> {
            kvList.add(k + "=" + v);
        });
        //带签名字符串
        String signingStr = StringUtils.join(kvList, "&") + apiKey;
        if(StringUtils.equalsIgnoreCase(type, "sha256")){
            return DigestUtils.sha256Hex(signingStr);
        }else{
            return DigestUtils.md5Hex(signingStr);
        }
    }

    /**
     * 校验参数的签名正确与否
     * @param params
     * @param apiKey
     * @return
     */
    public static boolean checkSign(Map<String, Object> params, String apiKey){
        String sign = (String) params.get("sign");
        params.remove("sign");
        String signResult = SimpleSignUtil.sign(params, apiKey,"MD5");
        if(StringUtils.equalsIgnoreCase(sign, signResult)){
            return true;
        }else{
            signResult = SimpleSignUtil.sign(params, apiKey, "SHA256");
            if(StringUtils.equalsIgnoreCase(sign, signResult)){
                return true;
            }
        }
        return false;
    }
}
