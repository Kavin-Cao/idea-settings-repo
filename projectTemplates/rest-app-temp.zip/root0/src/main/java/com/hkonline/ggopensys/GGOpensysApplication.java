package ${IJ_BASE_PACKAGE}.ggopensys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;



@SpringBootApplication
@ComponentScan("${IJ_BASE_PACKAGE}")
@EnableJpaRepositories(basePackages = "${IJ_BASE_PACKAGE}")
@EntityScan(basePackages = "${IJ_BASE_PACKAGE}")
@EnableConfigurationProperties({GGOpensysProperties.class})
public class GGOpensysApplication {
    public static void main(String[] args) {
        SpringApplication.run(GGOpensysApplication.class, args);
    }
}
