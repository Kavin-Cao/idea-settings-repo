package ${IJ_BASE_PACKAGE}.ggopensys;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Data
@ConfigurationProperties(prefix = "gg.opensys")
public class GGOpensysProperties {
	private Map<String, Object> apiKey;
}
