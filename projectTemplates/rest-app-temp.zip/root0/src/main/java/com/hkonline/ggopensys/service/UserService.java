package ${IJ_BASE_PACKAGE}.ggopensys.service;

import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.crypto.digest.MD5;
import com.alibaba.fastjson.JSON;
import ${IJ_BASE_PACKAGE}.common.dto.ApiResponse;
import ${IJ_BASE_PACKAGE}.datarepo.dao.member.MemberBaseInfoDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.member.MemberBonusAccmountDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.member.MemberContactInfoDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.member.MemberFundAccountMasterDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.opensys.OpensysGgUserDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.opensys.OpensysSimpleAuthLogDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.sys.SysFundTypeDao;
import ${IJ_BASE_PACKAGE}.datarepo.entity.member.MemberBaseInfo;
import ${IJ_BASE_PACKAGE}.datarepo.entity.member.MemberBonusAccmount;
import ${IJ_BASE_PACKAGE}.datarepo.entity.member.MemberContactInfo;
import ${IJ_BASE_PACKAGE}.datarepo.entity.member.MemberFundAccountMaster;
import ${IJ_BASE_PACKAGE}.datarepo.entity.opensys.OpensysGgUser;
import ${IJ_BASE_PACKAGE}.datarepo.entity.opensys.OpensysSimpleAuthLog;
import ${IJ_BASE_PACKAGE}.datarepo.entity.sys.SysFundType;
import ${IJ_BASE_PACKAGE}.ggopensys.vo.SimpleAuthVo;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static ${IJ_BASE_PACKAGE}.common.dto.ApiResponse.success;

@Service
public class UserService {

    private static final String DEFAULT_PARENT_USER_MOBILE = "17776851555";
    private static final String DEFAULT_LOGIN_PWD = "123456";

    private static final String PREFIX_GG_USERID = "GG";

    @Autowired
    private MemberBaseInfoDao memberBaseInfoDao;

    @Autowired
    private SysFundTypeDao sysFundTypeDao;

    @Autowired
    private MemberFundAccountMasterDao memberFundAccountMasterDao;

    @Autowired
    private MemberBonusAccmountDao memberBonusAccmountDao;

    @Autowired
    private MemberContactInfoDao memberContactInfoDao;

    @Autowired
    private OpensysGgUserDao opensysGgUserDao;

    @Autowired
    private OpensysSimpleAuthLogDao opensysSimpleAuthLogDao;

    @Transactional
    public ApiResponse simpleAuth(SimpleAuthVo vo) {
        String mobile = StringUtils.trim(vo.getMobile());
        String syschannel = StringUtils.trim(vo.getSyschannel());
        if(StringUtils.isBlank(mobile)){
            ApiResponse resp = ApiResponse.error(1001, "手机号码不能为空");
            this.simpleAuthLog(null, null, null, syschannel, vo, resp);
            return resp;
        }
        int mobileLen = StringUtils.length(mobile);
        if(mobileLen > 6 && !mobile.matches("\\d+")){
            ApiResponse resp = ApiResponse.error(1002, "手机号码格式错误");
            this.simpleAuthLog(null, null, null, syschannel, vo, resp);
            return resp;
        }
        String countryCode = StringUtils.trim(vo.getCountryCode());
        String nickname = StringUtils.trim(vo.getNickname());
        if(StringUtils.isBlank(nickname)){
            nickname = mobile;
        }
        MemberBaseInfo memberInfo = memberBaseInfoDao.findByMobileNo(mobile);
        if(memberInfo == null){
            memberInfo = this.newOneMember(countryCode, mobile, nickname);
        }

        if(memberInfo.getPushCode() == null){
            MemberBaseInfo parentUser = memberBaseInfoDao.findByMobileNo(DEFAULT_PARENT_USER_MOBILE);
           if(parentUser != null){
               memberInfo.setPushCode(parentUser.getReferralCode());
               memberBaseInfoDao.save(memberInfo);
           }
        }

        Long memberId = memberInfo.getId();
        OpensysGgUser opensysGgUser = opensysGgUserDao.findByMemberIdAndSyschannel(memberId, syschannel);
        boolean firstAuth = false;
        if(opensysGgUser == null){
            firstAuth = true;
            opensysGgUser = new OpensysGgUser();
            opensysGgUser.setCreateTime(new Date());
            opensysGgUser.setMemberId(memberId);
            opensysGgUser.setSyschannel(syschannel);
            String uuid = UUID.randomUUID().toString()
                    .replaceAll("\\-", "");
            uuid = StringUtils.join(syschannel, ":", uuid);
            String ggUserId = String.format(PREFIX_GG_USERID + "%s",
                    MD5.create().digestHex(uuid,"UTF-8")).toLowerCase();
            opensysGgUser.setGgUserId(ggUserId);
            opensysGgUserDao.save(opensysGgUser);
        }
        String ggUserId = opensysGgUser.getGgUserId();
        ApiResponse resp = success().ofData("ggUserId", ggUserId);
        this.simpleAuthLog(ggUserId, memberId, firstAuth, syschannel, vo, resp);
        return resp;
    }

    private void simpleAuthLog(
            String ggUserId,
            Long memberId,
            Boolean first,
            String syschannel,
            SimpleAuthVo vo,
            ApiResponse resp
    ){
        ThreadUtil.execute(() -> {
            OpensysSimpleAuthLog opensysSimpleAuthLog = new OpensysSimpleAuthLog();
            opensysSimpleAuthLog.setReqBody(JSON.toJSONString(vo));
            opensysSimpleAuthLog.setRespBody(JSON.toJSONString(resp));
            opensysSimpleAuthLog.setMemberId(memberId);
            opensysSimpleAuthLog.setGgUserId(ggUserId);
            opensysSimpleAuthLog.setFirst(first);
            opensysSimpleAuthLog.setSyschannel(syschannel);
            opensysSimpleAuthLog.setCreateTime(new Date());
            opensysSimpleAuthLogDao.save(opensysSimpleAuthLog);
        });
    }

    private MemberBaseInfo newOneMember(String countryCode, String mobile, String nickname){
        //生成全新的用户
        MemberBaseInfo memberInfo;
        Date now = new Date();
       synchronized (UserService.class){
           memberInfo = new MemberBaseInfo();
           memberInfo.setReferralCode(Integer.valueOf(this.generateReferralCode()));;
           memberInfo.setLoginPwd(MD5.create().digestHex(DEFAULT_LOGIN_PWD.concat("hkonline")));
           memberInfo.setTradePwd(null); //设置为空让用户初次交易时设置
           memberInfo.setMobileNo(mobile);
           memberInfo.setNickName(nickname);
           memberInfo.setHeadImg("/static/uploads/image/defaultHeadImg.png");
           memberInfo.setCreateTime(now);
           memberInfo.setModifyTime(now);
           memberInfo.setMemberLevel("1");
           memberInfo.setNickModityState("2");
           memberInfo.setPhoneBandState("2");
           memberInfo.setEmailBandState("1");
           memberInfo.setAuthState("1");
           memberInfo.setPushNum(0);
           memberInfo.setSalesTotal(BigDecimal.ZERO);
           memberInfo.setEnableFlag("1");
           memberInfo = memberBaseInfoDao.save(memberInfo);
       }

        Long memberId = memberInfo.getId();

        // 会员联系信息
        MemberContactInfo memberContactInfo = new MemberContactInfo();
        memberContactInfo.setMemberId(memberId);
        memberContactInfo.setMobileNo(mobile);
        memberContactInfo.setCreateTime(now);
        memberContactInfo.setModifyTime(now);
        memberContactInfo.setEnableFlag("1");
        memberContactInfo.setAuditState("1");
        memberContactInfo.setCountryCode(countryCode);
        memberContactInfoDao.save(memberContactInfo);

        List<SysFundType> sysFundTypeList = sysFundTypeDao.findAll();
        for (SysFundType sysFundType : sysFundTypeList) {
            MemberFundAccountMaster memberFundAccountMaster = memberFundAccountMasterDao
                    .findByMemberIdAndFundType(memberId, sysFundType.getId());
            if (memberFundAccountMaster == null) {
                memberFundAccountMaster = new MemberFundAccountMaster();
                memberFundAccountMaster.setMemberId(memberId);
                memberFundAccountMaster.setFundName(sysFundType.getFundName());
                memberFundAccountMaster.setFundType(sysFundType.getId());
                memberFundAccountMaster.setCreateTime(now);
                memberFundAccountMaster.setModifyTime(now);
                memberFundAccountMaster.setAvailAmount(BigDecimal.ZERO);
                memberFundAccountMaster.setAwardAmount(BigDecimal.ZERO);
                memberFundAccountMaster.setFundAmount(BigDecimal.ZERO);
                memberFundAccountMaster.setEnableFlag("1");
                memberFundAccountMasterDao.save(memberFundAccountMaster);
            }
        }
        if(memberBonusAccmountDao.findByMemberId(memberId) == null){
            MemberBonusAccmount memberBonusAccmount = new MemberBonusAccmount();
            memberBonusAccmount.setMemberId(memberId);
            memberBonusAccmount.setCreateTime(now);
            memberBonusAccmount.setModifyTime(now);
            memberBonusAccmount.setBonusAmount(BigDecimal.ZERO);
            memberBonusAccmount.setBonusSalesAmount(BigDecimal.ZERO);
            memberBonusAccmount.setBonusDirectAmount(BigDecimal.ZERO);
            memberBonusAccmount.setBonusManageAmount(BigDecimal.ZERO);
            memberBonusAccmount.setEnableFlag("1");
            memberBonusAccmountDao.save(memberBonusAccmount);
        }
        return memberInfo;
    }

    public Integer generateReferralCode() {
        Integer searchTimes = 1000000-1-1; //六位数的大小,出去000000和1000000
        for (int i = 0; i < searchTimes; i++) {
            String code = RandomStringUtils.randomNumeric(6);
            Integer intCode = Integer.valueOf(code);
            if (memberBaseInfoDao.findByReferralCode(intCode) == null) {
                return intCode;
            }

        }
        return null;
    }
}
