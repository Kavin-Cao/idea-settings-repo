package ${IJ_BASE_PACKAGE}.ggopensys.controller;

import ${IJ_BASE_PACKAGE}.common.dto.ApiResponse;
import ${IJ_BASE_PACKAGE}.ggopensys.service.HCouponService;
import ${IJ_BASE_PACKAGE}.ggopensys.vo.HCouponExchangeVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hcoupon")
public class HCouponController extends BaseController {

    @Autowired
    private HCouponService hcouponService;

    @PostMapping("/HCouponExchange")
    public ApiResponse HCouponExchange(HCouponExchangeVo vo) {
        return hcouponService.HCouponExchange(vo);
    }
}
