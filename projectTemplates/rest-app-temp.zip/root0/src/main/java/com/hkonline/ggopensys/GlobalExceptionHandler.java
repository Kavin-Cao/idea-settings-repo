package ${IJ_BASE_PACKAGE}.ggopensys;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import ${IJ_BASE_PACKAGE}.common.dto.ApiResponse;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import java.util.*;

import static org.springframework.http.HttpStatus.NOT_EXTENDED;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @Value("#[[\$]]#{spring.profiles.active}")
    private String env;

    /**
     * 在controller里面内容执行之前，校验一些参数不匹配啊，Get post方法不对啊之类的
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception e, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        Map<String,Object> params = Maps.newHashMap();
        Iterator<String> parameterNames = request.getParameterNames();
        while (parameterNames.hasNext()) {
            String name = parameterNames.next();
            String val = request.getParameter(name);
            params.put(name, val);
        }

        Map<String, Object> headersMap = Maps.newHashMap();
        Set<String> headerNames = headers.keySet();
        for (String name : headerNames){
            headersMap.put(name, headers.get(name));
        }
        ApiResponse result = log(request.getDescription(true), e, params, headersMap);
        return new ResponseEntity<>(result, NOT_EXTENDED);
    }

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public String jsonHandler(HttpServletRequest request, Exception e) {
        Map<String,Object> params = Maps.newHashMap();
        Enumeration<String> enumeration = request.getParameterNames();
        while (enumeration.hasMoreElements()) {
            String name = enumeration.nextElement();
            String val = request.getParameter(name);
            params.put(name, val);
        }
        Enumeration<String> headerNames = request.getHeaderNames();
        Map<String, Object> headers = Maps.newHashMap();
        while (headerNames.hasMoreElements()){
            String name = headerNames.nextElement();
            Enumeration<String> val = request.getHeaders(name);
            headers.put(name, val);
        }
        ApiResponse result = log(request.getRequestURL().toString(), e, params, headers);
        return JSON.toJSONString(result);
    }

    private ApiResponse log(String requestUrl, Exception ex, Map<String,Object> params, Map<String, Object> headers) {
        StackTraceElement[] error = ex.getStackTrace();
        List<String> traces = Lists.newArrayList();
        for (StackTraceElement stackTraceElement : error) {
            traces.add(stackTraceElement.toString());
        }
        String cause = "";
        if(ex.getCause() != null){
            cause = ex.getCause().toString();
        }

        String errorMsg = ex.getMessage();
        ApiResponse apiResponse;
        if (StringUtils.equalsIgnoreCase(env, "prod")) {
            apiResponse = ApiResponse.error(ApiResponse.CODE_DEFAULT__EXCEPTION, "系统繁忙,请稍后再试!");
        }else{
            apiResponse = ApiResponse.error(ApiResponse.CODE_DEFAULT__EXCEPTION, "系统异常!")
                    .ofData("requestUrl", requestUrl)
                    .ofData("requestBody", params)
                    .ofData("headers", headers)
                    .ofData("cause", cause)
                    .ofData("errorMsg", errorMsg)
                    .ofData("stackTrace", traces);
        }
        logger.error(
                "↓↓↓↓↓↓↓↓请求异常↓↓↓↓↓↓↓↓\n" +
                    "requestUrl={},\n" +
                    "requestBody={},\n" +
                    "headers={},\n" +
                "↑↑↑↑↑↑↑↑请求异常↑↑↑↑↑↑↑↑",
                requestUrl,params,headers
        );
        logger.error("异常信息",ex);
        return apiResponse;


    }
}