package ${IJ_BASE_PACKAGE}.ggopensys.service;

import ${IJ_BASE_PACKAGE}.common.dto.ApiResponse;
import ${IJ_BASE_PACKAGE}.datarepo.dao.member.MemberBaseInfoDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.member.MemberFundAccountMasterDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.opensys.OpensysGgUserDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.opensys.OpensysHCouponExchangedDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.sys.SysFundFlowDao;
import ${IJ_BASE_PACKAGE}.datarepo.dao.sys.SysFundTypeDao;
import ${IJ_BASE_PACKAGE}.datarepo.entity.member.MemberBaseInfo;
import ${IJ_BASE_PACKAGE}.datarepo.entity.member.MemberFundAccountMaster;
import ${IJ_BASE_PACKAGE}.datarepo.entity.opensys.OpensysGgUser;
import ${IJ_BASE_PACKAGE}.datarepo.entity.opensys.OpensysHcouponExchanged;
import ${IJ_BASE_PACKAGE}.datarepo.entity.sys.SysFundFlow;
import ${IJ_BASE_PACKAGE}.datarepo.entity.sys.SysFundType;
import ${IJ_BASE_PACKAGE}.ggopensys.vo.HCouponExchangeVo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.Path;
import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.Date;

@Service
public class HCouponService {

    private static final String H_COUPON_FUND_NAME = "H-COUPON";

    @Autowired
    private MemberBaseInfoDao memberBaseInfoDao;

    @Autowired
    private OpensysGgUserDao opensysGgUserDao;

    @Autowired
    private OpensysHCouponExchangedDao opensysHCouponExchangedDao;

    @Autowired
    private SysFundTypeDao sysFundTypeDao;

    @Autowired
    private MemberFundAccountMasterDao memberFundAccountMasterDao;

    @Autowired
    private SysFundFlowDao sysFundFlowDao;

    @Transactional
    public ApiResponse HCouponExchange(HCouponExchangeVo vo) {
        String ggUserId = vo.getGgUserId();
        if(StringUtils.isBlank(ggUserId)){
            return ApiResponse.error(1001, "港港用户id不能为空");
        }
        OpensysGgUser opensysGgUser = opensysGgUserDao.findByGgUserId(ggUserId);
        if(opensysGgUser == null){
            return ApiResponse.error(1002, "港港用户不存在");
        }
        String syschannel = StringUtils.trim(vo.getSyschannel());
        Double hcoupons = vo.getHcoupons();
        if(hcoupons == null || hcoupons.isNaN() || hcoupons <= 0 ){
            return ApiResponse.error(1004, "H券金额有误");
        }
        Long memberId = opensysGgUser.getMemberId();
        String orderNo = vo.getOrder();
        OpensysHcouponExchanged HCouponExchanged;
        synchronized (HCouponService.class){
            HCouponExchanged = opensysHCouponExchangedDao.findOne((Specification<OpensysHcouponExchanged>) (root, query, criteriaBuilder) -> {
                Path<String> orderNoPath = root.get("orderNo");
                Path<Long> memberIdPath = root.get("memberId");
                Path<String> syschannelPath = root.get("syschannel");
                return criteriaBuilder.and(
                        criteriaBuilder.equal(orderNoPath, orderNo),
                        criteriaBuilder.equal(memberIdPath, memberId),
                        criteriaBuilder.equal(syschannelPath, syschannel)
                );
            }).orElse(null);
        }
        if(HCouponExchanged != null){
            return ApiResponse.error(1005, "重复兑换");
        }

        MemberBaseInfo member = memberBaseInfoDao.findById(memberId).get();
        Date now = new Date();
        //查询用户的H券资金账户存在不
        SysFundType sysFundType = sysFundTypeDao.findByFundName(H_COUPON_FUND_NAME);
        Long fundTypeId = sysFundType.getId();
        MemberFundAccountMaster memberFundAccount = memberFundAccountMasterDao.findByMemberIdAndFundType(memberId, fundTypeId);
        if(memberFundAccount == null){
            memberFundAccount = new MemberFundAccountMaster();
            memberFundAccount.setMemberId(memberId);
            memberFundAccount.setFundType(fundTypeId);
            memberFundAccount.setFundName(sysFundType.getFundName());
            memberFundAccount.setFundAmount(BigDecimal.ZERO);
            memberFundAccount.setAvailAmount(BigDecimal.ZERO);
            memberFundAccount.setAwardAmount(BigDecimal.ZERO);
            memberFundAccount.setCreateTime(now);
            memberFundAccount.setModifyTime(now);
            memberFundAccount.setEnableFlag("1");
            memberFundAccount = memberFundAccountMasterDao.save(memberFundAccount);
        }
        BigDecimal fundAmount = memberFundAccount.getFundAmount();
        fundAmount = fundAmount == null ? BigDecimal.ZERO : fundAmount;
        BigDecimal availAmount = memberFundAccount.getAvailAmount();
        availAmount = availAmount == null ? BigDecimal.ZERO : availAmount;
        BigDecimal _hcoupons_ = BigDecimal.valueOf(hcoupons);
        memberFundAccount.setFundAmount(fundAmount.add(_hcoupons_));
        memberFundAccount.setAvailAmount(availAmount.add(_hcoupons_));
        memberFundAccount.setModifyTime(now);
        memberFundAccountMasterDao.save(memberFundAccount);

        //记录流转记录
        SysFundFlow sysFundFlow = new SysFundFlow();
        sysFundFlow.setTransferId(String.valueOf(memberId));
        sysFundFlow.setReceiveId(String.valueOf(memberId));
        sysFundFlow.setFundType(fundTypeId);
        sysFundFlow.setFundName(sysFundType.getFundName());
        sysFundFlow.setTransferAmount(_hcoupons_);
        sysFundFlow.setAccountAmount(memberFundAccount.getAvailAmount());
        sysFundFlow.setTransferRemark(String.format("来自%s兑换H券", syschannel));
        sysFundFlow.setTransferState("1");
        sysFundFlow.setTransferTime(now);
        sysFundFlow.setOperId(memberId);
        sysFundFlow.setOperName(member.getMobileNo());
        sysFundFlow.setEnableFlag("1");
        sysFundFlow.setTransferType(SysFundFlow.TransferType.充值);
        sysFundFlow.setOrderNo(orderNo);
        sysFundFlowDao.save(sysFundFlow);

        //记录开放系统兑换记录
        HCouponExchanged = new OpensysHcouponExchanged();
        HCouponExchanged.setMemberId(memberId);
        HCouponExchanged.setExchangedCoupons(_hcoupons_);
        HCouponExchanged.setExchangedTime(now);
        HCouponExchanged.setSyschannel(vo.getSyschannel());
        HCouponExchanged.setAvailAmountBefore(availAmount);
        HCouponExchanged.setAvailAmountAfter(memberFundAccount.getAvailAmount());
        HCouponExchanged.setOrderNo(orderNo);
        opensysHCouponExchangedDao.save(HCouponExchanged);

        return ApiResponse.success().ofData("hcoupons",memberFundAccount.getFundAmount());
    }
}
