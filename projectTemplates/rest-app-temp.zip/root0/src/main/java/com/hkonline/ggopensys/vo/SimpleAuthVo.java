package ${IJ_BASE_PACKAGE}.ggopensys.vo;

import lombok.Data;

@Data
public class SimpleAuthVo extends BaseOpenVo {
    private String mobile; //用户手机号的MD5值
    private String nickname; //昵称
    private String countryCode; //国际区号
}
