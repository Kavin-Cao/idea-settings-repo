package ${IJ_BASE_PACKAGE}.ggopensys;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.google.common.collect.Maps;
import ${IJ_BASE_PACKAGE}.common.dto.ApiResponse;
import ${IJ_BASE_PACKAGE}.ggopensys.util.SimpleSignUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Map;

public class SignCheckInterceptor extends HandlerInterceptorAdapter {
    @Autowired
    private GGOpensysProperties ggOpensysProperties;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler){
        Map<String, Object> reqParams = Maps.newHashMap();
        Enumeration<String> parameterNames = request.getParameterNames();
        while (parameterNames.hasMoreElements()){
            String key = parameterNames.nextElement();
            String val = request.getParameter(key);
            reqParams.put(key, val);
        }

        // 通过syschannel查询该系统的apiKey
        String syschannel = request.getParameter("syschannel");
        if(StringUtils.isBlank(syschannel) || !ggOpensysProperties.getApiKey().containsKey(syschannel)){
            checkErrorMsg(ApiResponse.error(1003, "系统名称错误"), response);
            return false;
        }
        String nonceStr = request.getParameter("nonceStr");
        if(StringUtils.isBlank(nonceStr)){
            checkErrorMsg(ApiResponse.error(1005, "签名随机码不能为空"), response);
            return false;
        }
        String apiKey = (String) ggOpensysProperties.getApiKey().get(syschannel);
        boolean signOK = SimpleSignUtil.checkSign(reqParams, apiKey);
        if(!signOK){
            checkErrorMsg(ApiResponse.error(ApiResponse.CODE_DEFAULT__TOKEN_ERROR, "签名错误"), response);
            return false;
        }
        return true;
    }

    private void checkErrorMsg(ApiResponse apiResponse, HttpServletResponse response){
        PrintWriter writer = null;
        try {
            response.setCharacterEncoding("utf-8");
            response.setHeader("content-type", "application/json;charset=utf-8");
            response.setHeader("Access-Control-Allow-Origin", "*");
            writer = response.getWriter();
            writer.write(JSON.toJSONString(apiResponse, SerializerFeature.WriteDateUseDateFormat));
            response.flushBuffer();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if (writer != null){
                try{
                    writer.close();
                }catch (Exception e2){

                }
            }

        }
    }
}
