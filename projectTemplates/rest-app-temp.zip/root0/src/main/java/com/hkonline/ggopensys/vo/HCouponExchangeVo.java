package ${IJ_BASE_PACKAGE}.ggopensys.vo;

import lombok.Data;

@Data
public class HCouponExchangeVo extends BaseOpenVo {
    private String ggUserId; //港港用户id
    private Double hcoupons; //H券金额
    private String order; //订单号,唯一值,不允许重复
}
