package ${IJ_BASE_PACKAGE}.ggopensys.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class BaseOpenVo implements Serializable {
    private String syschannel; //系统名称,默认HERMES
    private String sign; //签名,－签名规则说明
    private String nonceStr; //参与签名的随机字符串
}
